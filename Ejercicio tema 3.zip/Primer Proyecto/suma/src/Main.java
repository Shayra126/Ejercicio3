public class Main {
    public static void main(String[] args) {
        int num1 = 3;
        int num2 = 100;
        int num3 = 50;

        int resultado = suma(num1, num2, num3);
        System.out.println(resultado);

        Coche miCoche = new Coche();
        miCoche.AgregarPuerta();
        System.out.println(miCoche.puertas);

    }

    public static int suma(int num1, int num2, int num3) {
        return num1 + num2 + num3;
    }
}

class Coche {
    public int puertas = 4;

    public void AgregarPuerta() {
        this.puertas++;
    }
}